import time
import socket
import random


class Publisher:
    def __init__(self, broker_host, broker_port):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def publish(self, topic, mote_id, message, priority=1):
        # Message format: topic|priority|mote_id|payload
        message_packet = f"{topic}|{priority}|{mote_id}|{message}"
        self.socket.sendto(message_packet.encode('utf-8'), (self.broker_host, self.broker_port))
        print(f"Published: {message_packet}")


def simulate_ddos_attack():
    publisher = Publisher("localhost", 1884)
    topic = "sensor/temp"
    mote_id = 5  
    while True:
        message = "Attack data" *20  
        priority = 1  
        publisher.publish(topic, mote_id, message, priority)
        time.sleep(0.01)  

if __name__ == "__main__":
    simulate_ddos_attack()
