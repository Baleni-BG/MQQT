import socket
import threading
import transaction

SUBSCRIBER_HOST = 'localhost'
SUBSCRIBER_PORT = 1884
BROKER_HOST = 'localhost'
BROKER_PORT = 1883

class Subscriber:
    def __init__(self, topic):
        self.topic = topic
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((SUBSCRIBER_HOST, SUBSCRIBER_PORT))

        print(f"Subscriber listening on {SUBSCRIBER_HOST}:{SUBSCRIBER_PORT}")
        self.subscribe()

    def subscribe(self):
       
        self.socket.sendto(self.topic.encode('utf-8'), (BROKER_HOST, BROKER_PORT))
        stored_messages = transaction.retrieve_messages(self.topic)
        sorted_messages = sorted(stored_messages, key=lambda x: x[1], reverse=True) # Fisrte retrieve mess and then sorted by order of importance.

       
        for message in sorted_messages:
            print(f"Retrieved stored message: {message[0]} (Priority: {message[1]})")

    def listen(self):
        while True:
            message, address = self.socket.recvfrom(1024)
            print(f"Received message on topic '{self.topic}': {message.decode('utf-8')}")

if __name__ == "__main__":
    topic = input("Enter the topic you want to subscribe to: ")
    subscriber = Subscriber(topic)
    listener_thread = threading.Thread(target=subscriber.listen)
    listener_thread.start()
