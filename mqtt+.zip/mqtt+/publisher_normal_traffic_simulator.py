import time
import random
import socket
import threading


class Publisher:
    def __init__(self, broker_host, broker_port, mote_id):
        self.broker_host = broker_host
        self.broker_port = broker_port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.mote_id = mote_id

    def publish(self, topic, message, priority=1):
        message_packet = f"{topic}|{priority}|{self.mote_id}|{message}"
        self.socket.sendto(message_packet.encode('utf-8'), (self.broker_host, self.broker_port))
        print(f"Published from mote {self.mote_id}: {message_packet}")


def simulate_mote_traffic(mote_id):
    publisher = Publisher("localhost", 1884, mote_id)
    topics = ["sensor/temp"]
    while True:
        topic = topics[0]
        message = f"Normal data from mote {mote_id} - {random.randint(1, 100)}"
        priority = random.choice([1, 2, 3])  # Random priority for variation
        publisher.publish(topic, message, priority)
        time.sleep(random.uniform(0.5, 2.0))  # Messages are sent between 0.5 sec to 2.0 sec

def start_publishers():
    num_motes = int(input("Enter the number of motes (publishers) to create: "))
    threads = [] # Creating a treadpull for each pub
    for mote_id in range(1, num_motes + 1):
        thread = threading.Thread(target=simulate_mote_traffic, args=(mote_id,))
        thread.start()
        threads.append(thread)
   
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    start_publishers()
