import socket
import threading
import csv
from queue import PriorityQueue

# Broker class with CSV logging
class Broker:
    def __init__(self, host, port, csv_file="mqtt_traffic_log.csv"):
        self.host = host
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((self.host, self.port))
        self.clients = {}
        self.csv_file = csv_file
        self.lock = threading.Lock()
        self.priority_queue = PriorityQueue()

        # write on a file / creat file
        with open(self.csv_file, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Topic", "Priority", "Mote ID", "Message"])

    def handle_message(self, message):
        topic, priority, mote_id, payload = message.split("|")
        priority = int(priority)
        self.priority_queue.put((priority, topic, mote_id, payload))

       
        with self.lock:
            with open(self.csv_file, mode='a', newline='') as file:
                writer = csv.writer(file)
                writer.writerow([topic, priority, mote_id, payload])
            print(f"Logged message to {self.csv_file}: {message}")

    def broker_loop(self):
        print(f"Broker listening on {self.host}:{self.port}")
        while True:
            message, addr = self.socket.recvfrom(1024)
            self.handle_message(message.decode('utf-8'))

    def start(self):
        threading.Thread(target=self.broker_loop).start()

if __name__ == "__main__":
    broker = Broker("localhost", 1884)
    broker.start()
