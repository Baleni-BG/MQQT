To Simulate a normal traffic 

1. Run the broker.py
2. Run publisher_normal_traffic_simulator.py , limit to 4 motes


Traffic data will be written on a csv file

*************************************************************************

To add an attack to the network

1. Additionally run attack_publisher.py

A ddos attack will be exhibited and logged to a csv file.


###############################################################################################################
To Simulate a pub/sub network

1. Run broker.py
2. Run publisher.py or subscriber.py 
3. Run publisher.py or subscriber.py 

Messages will be logged to on the database provided , and will be recievd in realtime by the subscriber.