
import sqlite3

DATABASE_FILE = "mqtt+.db"

def create_tables():
    with sqlite3.connect(DATABASE_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''CREATE TABLE IF NOT EXISTS messages (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            topic TEXT NOT NULL,
                            message TEXT NOT NULL,
                            priority INTEGER NOT NULL,
                            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                          )''')
        conn.commit()

def insert_message(topic, message, priority):
    with sqlite3.connect(DATABASE_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO messages (topic, message, priority)
                          VALUES (?, ?, ?)''', (topic, message, priority))
        conn.commit()

def retrieve_messages(topic):
    with sqlite3.connect(DATABASE_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute('''SELECT message FROM messages WHERE topic = ?
                          ORDER BY priority DESC, timestamp ASC''', (topic,))
        return cursor.fetchall()
