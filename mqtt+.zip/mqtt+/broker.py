
import socket
import threading
import transaction

BROKER_HOST = 'localhost'
BROKER_PORT = 1883

transaction.create_tables()

class Broker:
    def __init__(self):
        self.subscribers = {}

    def start(self):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        server_socket.bind((BROKER_HOST, BROKER_PORT))

        print(f"Broker started on {BROKER_HOST}:{BROKER_PORT}")

        while True:
            message, address = server_socket.recvfrom(1024)
            decoded_message = message.decode('utf-8')
            print(f"Received message from publisher: {decoded_message}")

            topic, msg, priority = decoded_message.split('|')
            priority = int(priority)

            transaction.insert_message(topic, msg, priority)
            self.forward_message(topic, msg, priority)

    def forward_message(self, topic, msg, priority):
        if topic in self.subscribers:
            for subscriber in self.subscribers[topic]:
                subscriber.send_message(msg)

    def add_subscriber(self, topic, address):
        if topic not in self.subscribers:
            self.subscribers[topic] = []
        self.subscribers[topic].append(address)

if __name__ == "__main__":
    broker = Broker()
    broker.start()
