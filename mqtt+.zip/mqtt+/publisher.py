# publisher.py
import socket
import sys

PUBLISHER_HOST = 'localhost'
PUBLISHER_PORT = 1885
BROKER_HOST = 'localhost'  
BROKER_PORT = 1883
class Publisher:
    def __init__(self, topic):
        self.topic = topic
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((PUBLISHER_HOST, PUBLISHER_PORT))

    def publish(self, message, priority):
        formatted_message = f"{self.topic}|{message}|{priority}"
        self.socket.sendto(formatted_message.encode('utf-8'), (BROKER_HOST, BROKER_PORT))

if __name__ == "__main__":
    topic = input("Enter the topic you want to publish to: ")
    publisher = Publisher(topic)

    while True:
        message = input("Enter the message you want to publish: ")
        priority = input("Enter the message priority (higher is more critical): ")
        publisher.publish(message, int(priority))
